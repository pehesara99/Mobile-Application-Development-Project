package com.example.madproject

data class UserReg(val fullName:String?=null, val email:String?=null,val password:String?=null){

}
