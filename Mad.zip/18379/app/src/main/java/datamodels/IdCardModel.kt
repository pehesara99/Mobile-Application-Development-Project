package datamodels

data class IdCardModel(val imageUrl: String) {}